import ui.AccessSystemUI;

public class AccessSystemTest {
	public static void main(String[] args) {
		AccessSystemUI ui = new AccessSystemUI();
		ui.init();
	}
}
