package entity;

public enum DoorState {
	open,Close;
}
