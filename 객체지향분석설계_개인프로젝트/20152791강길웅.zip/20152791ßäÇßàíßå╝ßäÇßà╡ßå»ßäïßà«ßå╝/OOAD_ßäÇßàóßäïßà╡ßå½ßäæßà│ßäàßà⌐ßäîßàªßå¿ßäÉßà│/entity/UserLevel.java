package entity;

public enum UserLevel {
	//
	Unauthorized,authorized,manager;
}
