package util;

public class UserNullException extends Exception{

	private static final long serialVersionUID = -9134030079132608401L;

	public UserNullException(String message) {
		super(message);
	}
}
