package util;

public class UserAthorityException extends RuntimeException{

	private static final long serialVersionUID = -7227935864832822871L;
	
	public UserAthorityException(String message) {
		super(message);
	}
}
