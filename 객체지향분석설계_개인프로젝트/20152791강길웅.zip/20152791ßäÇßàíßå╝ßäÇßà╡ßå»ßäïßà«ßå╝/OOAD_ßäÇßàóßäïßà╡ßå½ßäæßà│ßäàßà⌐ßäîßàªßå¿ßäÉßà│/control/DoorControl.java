package control;

public interface DoorControl {
	
	public void open();
	public boolean isOpen();
	public void change();
}
